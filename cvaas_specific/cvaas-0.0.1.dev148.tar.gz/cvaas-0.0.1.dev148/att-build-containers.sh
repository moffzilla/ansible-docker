#!/bin/bash

docker rmi cvaas
docker build -f att-Dockerfile-cvaas -t cvaas .

docker rmi audit_test
docker build -f att-Dockerfile-python2 -t audit_test .
