#!/bin/bash

docker stop redis
docker rm redis

docker stop auditd
docker rm auditd
 
docker stop worker
docker rm worker
 
docker stop audit_test
#docker rm audit_test

docker network rm audit_network
