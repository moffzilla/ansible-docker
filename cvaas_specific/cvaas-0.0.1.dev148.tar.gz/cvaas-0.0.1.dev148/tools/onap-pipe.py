#!/usr/bin/env python

"""
Send ONAP like data to the redis server.
"""

import argparse
import datetime
import json
import sys
import uuid

import redis


def load_data(count, filename, host):
    try:
        r = redis.StrictRedis(host=host)
    except Exception as ex:
        print("Unable to connect to Redis Host: %s" % ex)
        sys.exit(1)

    for i in range(0, count):
        name = uuid.uuid4().get_hex().upper()[0:6]
        print('Sending data %s to %s...' % (name, host))

        onap_data = {
            'VNFC_TYPE': '',
            'VNF_ID': name,
            'VNF_NAME': name,
            'HOST_IP_ADDRESS': '127.0.0.1',
            'UPLOAD_DATE': str(datetime.date.today()),
            'ORIGINATOR_ID': name,
            'REQUEST_ID': name,
            'VNF_TYPE': 'vcvaas',
            'SERVICE_DESCRIPTION': '',
            'VM_NAME': name,
            '@timestamp': str(datetime.date.today()),
            'ACTION': 'audit',
            'PENDING_DELETE': 'null',
            'CONFIG_INDICATOR': 'Running',
            'UPLOAD_TIMESTAMP': str(datetime.date.today()),
            'CONTENT': ''
        }
        with open(filename) as f:
            data = f.read()
        onap_data['CONTENT'] = data

        r.publish('cvaas', json.dumps(onap_data))


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('-c', '--count', dest='count', default=1,
                        type=int, help='Generate a number of onap requests.')
    parser.add_argument('-d', '--data', dest='data',
                        help='Configuration file to use.')
    parser.add_argument('--host', '-H', dest='host', default='redis',
                        help='Redis server')
    opt = parser.parse_args()

    if not opt.data:
        print("You did not specify the configuration.")
        sys.exit(1)

    print("Sending %s packets to %s." % (opt.count, opt.host))
    load_data(opt.count, opt.data, opt.host)
