#!/usr/bin/env python

import argparse
import json
import sys
import uuid

from elasticsearch import Elasticsearch


def load_data(opt):
    es = Elasticsearch(opt.host)

    with open(opt.data) as f:
        data = f.read()
    data = json.loads(data)

    request_body = {
        "settings": {
            "index.mapping.total_fields.limit": 1000000000,
            "index.mapping.ignore_malformed": "true",
            "number_of_shards": 1,
            "number_of_replicas": 0
        }
    }
    if not es.indices.exists('cvaas-policy'):
        print('Creating cvaas-config indexes.')
        res = es.indices.create(
            index='cvaas-policy', body=request_body)
        print(res)

    u = uuid.uuid4().hex
    result = es.index(index='cvaas-policy', doc_type='cvaas-doc',
                      id=u, body=json.dumps(data))
    print(result)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('-d', '--data', dest='data',
                        help='Template to use')
    parser.add_argument('--host', '-H', dest='host', default='elasticsearch',
                        help='Elasticsearch server')
    opt = parser.parse_args()

    if not opt.data:
        print('You did not supply the template')
        sys.exit(1)

    print('Loaing template %s to %s' % (opt.data, opt.host))
    load_data(opt)
