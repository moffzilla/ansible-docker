#!/usr/bin/python

import json
import sys

data = sys.argv[1]
with open(data) as f:
    data = f.read()
data = json.loads(data)
for data in data.get('Rules').get('gsh').get('element').keys():
    print data
