These are tools for testing cvaas.

In order to run the redis-py library installed. It can be installed by doing
the followng:

sudo pip install redis

To run the onap-pipe script, please do the following:

python onap-pipe.py -H <redis host> -d data/config/vcvaas.data

data/config/vcvaas.data is an example configuration file that can be sent to
the engine for testing the engine.

