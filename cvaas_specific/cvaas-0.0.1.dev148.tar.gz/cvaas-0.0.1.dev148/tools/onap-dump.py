#!/usr/bin/env python

import argparse
import json
import sys
import uuid

from elasticsearch import Elasticsearch

cvaas_config = {
    'ericsson': 'cvaas-ericsson'
}


def load_data(opt):
    if opt.plugin not in cvaas_config:
        print("Unknown plugin %s" % opt.plugin)
        return

    es = Elasticsearch(opt.host)

    with open(opt.data) as f:
        data = f.read()
    data = json.loads(data)

    request_body = {
        "settings": {
            "index.mapping.total_fields.limit": 1000000000,
            "index.mapping.ignore_malformed": "true",
            "number_of_shards": 1,
            "number_of_replicas": 0
        }
    }
    if not es.indices.exists(cvaas_config[opt.plugin]):
        print('Creating cvaas-config indexes.')
        res = es.indices.create(
            index=cvaas_config[opt.plugin], body=request_body)
        print(res)

    if not es.indices.exists('cvaas-report'):
        print('Creating cvaas-report indexes.')
        res = es.indices.create(
            index='cvaas-report', body=request_body)
        print(res)

    u = uuid.uuid4().hex
    result = es.index(index=cvaas_config[opt.plugin], doc_type='cvaas-doc',
                      id=u, body=json.dumps(data))
    print(result)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('-d', '--data', dest='data',
                        help='Template to use')
    parser.add_argument('-p', '--plugin', dest='plugin',
                        help='Index to create to dump data into.')
    parser.add_argument('--host', '-H', dest='host', default='elasticsearch',
                        help='Elasticsearch server')
    opt = parser.parse_args()

    if not opt.data:
        print('You did not supply the template')
        sys.exit(1)

    print('Loaing template %s to %s' % (opt.data, opt.host))
    load_data(opt)
