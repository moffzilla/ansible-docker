#!/usr/bin/python3
import json
import sys

import six

with open(sys.argv[1]) as f:
    data = f.read()

data = json.loads(data)
for key in sorted(data['Rules']['gsh']['element']):
    for i, j in six.iteritems(data['Rules']['gsh']['element'][key]['element']):
        val = data['Rules']['gsh']['element'][key]['element'][i]['GoldStdVal']
        if isinstance(val, list):
            data['Rules']['gsh']['element'][key]['element'][i]['GoldStdVal'] = \
                dict(enumerate(x for x in val))
        else:
            data['Rules']['gsh']['element'][key]['element'][i]['GoldStdVal'] = \
                val

print(json.dumps(data))

# Notes
#
# download it chmod +x
# ./format_converter.py  vMME.json | jq . | less
# (assuming you have json installed)
