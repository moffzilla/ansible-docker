#!/bin/bash

docker run -it --rm \
--name audit_test \
--net audit_network \
--env REDISHOST=redis \
--env LOG_FILE=/logfile \
--volume $PWD/logfile:/logfile:rw \
audit_test
 
# test script:
#   python tools/onap-pipe.py -H redis -d tools/data/config/vcvaas.config


# really only need to run once...
#   python tools/onap-dump.py -H au4txvccrdp01-eth2.auk4.aic.cip.att.com -p ericsson -d tools/data/master/vcvaas.json

# onap-dump.py output:
#   Loaing template tools/data/master/vcvaas.json to au4txvccrdp01-eth2.auk4.aic.cip.att.com
#   Creating cvaas-config indexes.
#   {u'acknowledged': True, u'shards_acknowledged': True}
#   {u'_type': u'cvaas-doc', u'_shards': {u'successful': 1, u'failed': 0, u'total': 1}, u'_index': u'cvaas-ericsson', u'_version': 1, u'created': True, u'result': u'created', u'_id': u'f4c38197c68740df88e5ba0505a54540'}

# http://au4txvccrdp01-eth2.auk4.aic.cip.att.com:9200/cvaas-ericsson/_search?pretty
# http://au4txvccrdp01-eth2.auk4.aic.cip.att.com:9200/cvaas-ericsson/cvaas-doc/f4c38197c68740df88e5ba0505a54540
