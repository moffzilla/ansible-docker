======================
cvaas service overview
======================
The cvaas service provides...

The cvaas service consists of the following components:

``cvaas-api`` service
  Accepts and responds to end user compute API calls...
