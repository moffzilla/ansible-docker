2. Edit the ``/etc/cvaas/cvaas.conf`` file and complete the following
   actions:

   * In the ``[database]`` section, configure database access:

     .. code-block:: ini

        [database]
        ...
        connection = mysql+pymysql://cvaas:CVAAS_DBPASS@controller/cvaas
