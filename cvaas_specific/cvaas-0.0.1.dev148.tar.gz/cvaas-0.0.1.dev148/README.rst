CVAAS

== Things to install first ==

You need to have the following instatted on the host:

    - docker (latest)
    - docker-compose (latest)

== How to build the cvaas-api cvaas-engine ==

To build the cvaas docker container you need to do the following:

    docker build -t cvaas .

== To run the engine ==

To run the cvaas engine:

    docker-compose up --build

== To feed the engine == 

python tools/onap-pipe.py -H <ip of redis> -d tools/data/config/vcvaas.config
