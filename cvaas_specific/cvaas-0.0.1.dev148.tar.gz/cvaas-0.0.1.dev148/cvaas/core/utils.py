import logging
import sys

from cvaas.core import config
from cvaas.core import search

logger = logging.getLogger('cvaas')


def setup_logging():
    """Logging setup."""
    logger = logging.getLogger('cvaas')

    formatter = logging.Formatter(('%(asctime)s '
                                   '- %(name)s - %(levelname)s - %(message)s'))
    handler = None
    if config.LOG_FILE:
        handler = logging.FileHandler(config.LOG_FILE)
    else:
        handler = logging.StreamHandler(sys.stdout)

    logger.setLevel(config.LOG_LEVEL)
    handler.setLevel(config.LOG_LEVEL)
    handler.setFormatter(formatter)
    logger.addHandler(handler)


def load_master(index):
    """Load a master configuration for a given index."""
    logger.info('Loading master configuration from Elasticsearch..')

    query = {'query': {'match_all': {}}}
    return search.query(index, query)
