# Subscribe to the redis worker and process the results as the come in.

import logging
import sys
import time

import redis
from rq import Queue

from cvaas.core import config
from cvaas.core import job as worker

log = logging.getLogger('cvaas')


class CvaasRunner(object):
    def __init__(self, r, channels):
        self.redis = r
        self.pubsub = self.redis.pubsub()
        self.pubsub.subscribe(channels)

        self.conn = self._setup_redis(config.REDISHOST)
        self.queue = Queue('cvaas-worker', connection=self.conn)

    def subscriber(self):
        """Process the results of the data sent to the redis server. """
        try:
            for data in self.pubsub.listen():
                if data['type'] == 'subscribe':
                    continue
                if data['type'] == 'message' and \
                   data['data'] != 1:
                    job = self.queue.enqueue(
                        worker.process_job, data)
                    log.info('Processing cvaas job %s', job.id)
                else:
                    log.warning('recieve unknown message in '
                                'subscriber %(type)s',
                                {'type': data['type']})
        except Exception as e:
            log.warning('there is no more redis connection available: '
                        '%(e)s', {'e': e})

    def _setup_redis(self, redis_server, redis_server_port=6379, timeout=120,
                     polling_interval=5):
        """Poll the redis server until its up. Unless timeout."""
        log.info('Setting up the redis connection..')
        connection_pool = redis.ConnectionPool(
            host=redis_server, port=redis_server_port)

        redis_obj = redis.StrictRedis(connection_pool=connection_pool,
                                      socket_connect_timeout=1,
                                      socket_timeout=1,
                                      db=0)

        sucess = False

        retry_count = max(timeout // polling_interval, 1)
        # Check for connections to redis_server
        for retry in range(retry_count):
            try:
                redis_obj.get('test')
                sucess = True
            except (redis.exceptions.ConnectionError):
                # clear active exception to avoid the exception summary
                sys.exc_clear()
                log.info('Connection to redis server.. Retry #%d/%d', retry,
                         retry_count)
                time.sleep(polling_interval)
                continue
            break
        if not sucess:
            log.error('Cannot connect to the Redis server.')
            raise ValueError('Could not connect to Redis.')

        return redis_obj
