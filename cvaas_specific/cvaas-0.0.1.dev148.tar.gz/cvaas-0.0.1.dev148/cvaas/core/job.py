import logging

from cvaas.engine.manager import CvaasManager

log = logging.getLogger(__name__)


def process_job(payload):
    '''Process payload configuration.'''
    log.info('Processing payload from ONAP.')

    manager = CvaasManager()
    manager.process_job(payload)
