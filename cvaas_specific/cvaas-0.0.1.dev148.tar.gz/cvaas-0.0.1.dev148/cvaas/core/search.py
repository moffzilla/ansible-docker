import logging

import elasticsearch
from elasticsearch.helpers import bulk

from cvaas.core.config import ELASTICHOST

log = logging.getLogger(__name__)


def query(index, search=None):
    """Search the elasticsearch index."""
    log.info('Searching elasticsearch.')
    try:
        es = elasticsearch.Elasticsearch(ELASTICHOST)
        res = es.search(index=index, body=search)
    except elasticsearch.ConnectionError:
        raise Exception('Unable to connect to elasticsearch.')
    except Exception as e:
        raise Exception('Search operation failed: %s', e)
    hit_list = res['hits']['hits']
    return [x['_source'] for x in hit_list]


def insert(index, doc_type, uid, data):
    """Insert a document into the elasticsearch database."""
    log.info('Inserting %s into %s elasticsearch.', uid, index)
    try:
        es = elasticsearch.Elasticsearch(ELASTICHOST)
        res = es.create(index=index, doc_type=doc_type,
                        id=uid, body=data)
        created = res['created']
        version = res['_version']
    except elasticsearch.ConnectionError:
        raise Exception('Unable to connect to database.')
    except elasticsearch.TransportError as e:
        if e.status_code == 409:
            raise Exception('Document exists: %s', e)
        raise Exception('Insert operation failed: %s', e)
    except Exception as e:
        raise Exception('Insert operation failed: %s', e)
    return (created, version)


def get(index, uid):
    """Fetch a specific result of an elasticsearch query."""
    log.info('Fetching data from elasticsearch for %s.', uid)
    try:
        es = elasticsearch.Elasticsearch(ELASTICHOST)
        return es.get(index=index, id=uid, doc_type='cvaas-doc')
    except elasticsearch.ConnectionError:
        raise Exception('Unable to connect to database.')
    except Exception as e:
        raise Exception('Get opertaion failed: %s', e)


def bulk_insert(index, doc_type, uid, data):
    """Insert a document into the elasticsearch database."""
    log.info('Inserting bulk %s into %s elasticsearch.', uid, index)
    es = elasticsearch.Elasticsearch(ELASTICHOST)
    _actions = []
    action = {
        "_index": index,
        "_type": doc_type,
        "_source": data,
        "_id": uid,
    }
    _actions.append(action)
    res = bulk(es, _actions, index=index, raise_on_error=True)
    return res
