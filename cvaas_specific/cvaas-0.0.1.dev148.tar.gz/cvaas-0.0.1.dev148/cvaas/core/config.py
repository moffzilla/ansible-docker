import logging
import os

"""
Configuration for cvaas.
"""

# CVAAS configuration
LOG_FILE = os.getenv('LOG_FILE', None)
LOG_LEVEL = getattr(logging, os.getenv("LOG_LEVEL", "debug").upper())
PLUGIN = os.getenv('PLUGIN', '')
TEMPLATE_INDEX = os.getenv('TEMPALTE_INDEX', '')
POLICY_INDEX = os.getenv('POLICY_INDEX', '')
REGEX = os.getenv('REGEX', '/etc/cvaas/regex.cfg')

# CVAAS hosts
REDISHOST = os.getenv('REDISHOST', 'redis')
ELASTICHOST = os.getenv('ELASTICHOST', 'elasticsearch')
