import logging
import pprint

import dpath.util
from oslo_utils import importutils

from cvaas.core import search
from cvaas.engine.reports import report

log = logging.getLogger(__name__)


class ONAPLog(report.CvaasReport):
    """Generates a report to be inserted into elasticsearch.
    """

    def __init__(self, results, policy, cvaas_report, ResultsFilter):
        super(ONAPLog, self).__init__(results, policy, cvaas_report,
                                      ResultsFilter)
        self.results = results
        self.policy = policy
        self.report = cvaas_report
        self.ResultsFilter = ResultsFilter

    def run_report(self):
        """Generate a report for the end user"""
        log.info('Running ONAP log.')

        self.report['audit'] = self.results

        r = dpath.util.get(self.results, self.ResultsFilter)
        if r:
            results = {}
            for policy in self.policy:
                log.info('Applying policy %s', policy)
                results.setdefault(policy, [])
                for key in r.keys():
                    try:
                        result = importutils.import_object(
                            'cvaas.engine.policy.runner.%s' % policy,
                            result=r[key])
                    except Exception as ex:
                        log.exception('Unable to apply %s: %s', policy, ex)
                    if result:
                        for path, data in result:
                            if path:
                                path = "%s." % key + path
                                results[policy].append(path.replace('/', '.'))

                        self.cvaas_report['results'] = results

        log.info(pprint.pprint(self.cvaas_report))
        search.insert('cvaas-report', 'cvaas-doc',
                      self.cvaas_report.get('id'), self.report)
