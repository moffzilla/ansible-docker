import logging

log = logging.getLogger(__name__)


class CvaasReport(object):
    """Generates a custom report for cvaas.

    Base report for cvaas audit results. This includes
    the supported/required implementation for API calls.
    Also provides a *generic* implmemention of reporting
    features.
    """

    def __init__(self, results, policy, cvaas_report, ResultsFilter):
        self.results = results
        self.policy = policy
        self.cvaas_report = cvaas_report
        self.ResultsFilter = ResultsFilter

    def run_report(self):
        """Generate a report for the end user"""
        pass
