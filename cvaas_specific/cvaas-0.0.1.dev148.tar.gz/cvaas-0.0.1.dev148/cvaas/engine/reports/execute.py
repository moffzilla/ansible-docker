import logging

from cvaas.engine.reports import report

log = logging.getLogger(__name__)


class CvaasExecute(report.CvaasReport):
    """Generates a report to be inserted into elasticsearch.
    """

    def __init__(self, results, policy, cvaas_report, ResultsFilter):
        super(CvaasExecute, self).__init__(results, policy, cvaas_report,
                                           ResultsFilter)
        self.results = results
        self.policy = policy
        self.report = cvaas_report
        self.ResultsFilter = ResultsFilter

    def run_report(self):
        """Generate a report for the end user"""
        log.info('Running do-something.')
