import logging

from cvaas.engine.reports import report

log = logging.getLogger(__name__)


class CvaasMessage(report.CvaasReport):
    """Sends a message to Dmaap."""

    def __init__(self, results, policy, cvaas_report, ResultsFilter):
        super(CvaasMessage, self).__init__(results, policy, cvaas_report,
                                           ResultsFilter)
        self.results = results
        self.policy = policy
        self.report = cvaas_report
        self.ResultsFilter = ResultsFilter

    def run_report(self):
        """Generate a report for the end user"""
        log.info('Sending message somewhere.')
