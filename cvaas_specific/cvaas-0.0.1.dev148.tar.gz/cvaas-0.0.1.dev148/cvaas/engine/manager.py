"""Cvaas manager manages processing payload, auditing, and
processing of VNF configuration passed from ONAP.
"""

import datetime
import logging
import uuid
import yaml

import dpath.util

from oslo_serialization import jsonutils
from oslo_utils import importutils

from cvaas.core import config
from cvaas.core import utils

log = logging.getLogger(__name__)

PLUGIN_MAPPING = {
    'ericsson': 'cvaas.plugins.ericsson.plugin.Ericsson',
    'fake': 'cvaas.plugins.fake.plugin.FakePlugin'
}


class CvaasManager(object):
    """Manages the configuration and policy engine."""

    def __init__(self):
        """Load the plugin from the environment variable."""
        self.cvaas_config = {}
        self.cvaas_policy = {}
        self.cvaas_template = None
        self.payload = None

        self.cvaas_results = {}

        self.regex = yaml.load(open(config.REGEX))
        self.cvaas_report = self._create_results()

        plugin = config.PLUGIN
        if not plugin:
            plugin_config = 'ericsson'
        if plugin_config in PLUGIN_MAPPING:
            plugin = PLUGIN_MAPPING[plugin_config]

        template_index = config.TEMPLATE_INDEX
        if not template_index:
            self.template_index = 'cvaas-ericsson'
        policy_index = config.POLICY_INDEX
        if not policy_index:
            self.policy_index = 'cvaas-policy'

        self.report_filters = {
            'ONAP-Log': 'cvaas.engine.reports.onap.ONAPLog',
            'do-something': 'cvaas.engine.reports.execute.CvaasExecute',
            'pub-message': 'cvaas.engine.reports.message.CvaasMessage',
            'oss-msg': 'cvaas.engine.reports.message.CvaasMessage'
        }

        self.plugin = importutils.import_object(plugin)

        log.debug('Loading %s (version - %s) for %s.', plugin,
                  self.plugin.version, self.cvaas_results.get('id'))
        self.ResultsFilter = self.plugin.ResultsFilter

    def process_job(self, payload):
        """Process the payload recieved by redis."""
        log.info('Processing job.')

        try:
            # Validate the redis payload is correct.
            self._process_payload(payload)

            # Process the configuration from redis
            self.process_configuration()

            # Run the configuration aginst the gold master template.
            self.process_audit_rules()

            # Run the policy against the results of the audit.
            policies = self.process_audit_policy()

            # Create a report of the audit results.
            self.process_audit_report(policies)
        except Exception as ex:
            msg = 'Unable to process job: %s' % ex
            log.exception(msg)
            raise Exception(msg)

    def _process_payload(self, payload):
        """Check the data sent by redis."""
        try:
            if payload:
                content = jsonutils.loads(payload.get('data'))
        except AttributeError as ex:
            raise Exception('Unable to find configuration: %s', ex)
        except Exception as ex:
            raise Exception("Invalid data: %s", ex)
        if content and content.get('CONTENT'):
            self.payload = content

    def _create_results(self):
        """Build the results dictionary"""
        now = datetime.datetime.now()
        return {
            'id': str(uuid.uuid4()),
            'Date': str(now.strftime(("%Y-%m-%d_%Hh%M%z"))),
        }

    def process_configuration(self):
        """Process the configuration from the VNF device."""
        log.info('Processing configuration for cvaas auditing.')

        try:
            config = self.payload.get('CONTENT')
        except AttributeError as ex:
            raise Exception('Unable to parse configuration: %s', ex)
        except Exception as ex:
            raise Exception('Invalid data: %s', ex)

        if config:
            try:
                self.cvaas_config = self.plugin.load_configuration(config)
            except Exception:
                log.exception('Failed to parse configuration.')

    def process_audit_rules(self):
        """Apply the audit rules for the VNF configuraton."""
        log.info('Processing audit rules for cvaas auditing.')

        try:
            template = utils.load_master(self.template_index)[0]
        except Exception as ex:
            raise Exception('Failed to load configuration master template.')

        self.cvaas_template = template
        rules = self.plugin.load_rules()

        if rules:
            for rule in rules:
                log.info('Executing %s rule.', rule)
                try:
                    self.cvaas_results = importutils.import_object(
                        rules.get(rule),
                        config=self.cvaas_config,
                        template=self.cvaas_template,
                        results=self.cvaas_results,
                        regex=self.regex)
                except Exception as ex:
                    raise Exception('Failed to load %s: %s', rule, ex)

    def process_audit_policy(self):
        """Process the audit policy for the VNF configuration."""
        log.info('Processing audit policy for cvaas auditing.')

        try:
            cvaas_policy = utils.load_master(self.policy_index)[0]
        except Exception as ex:
            raise Exception('Failed to load policy template: %s', ex)

        conditions = self.plugin.load_policy(self.cvaas_template)
        if conditions:
            reports = {}
            for condition in conditions:
                log.info('Loading %s', condition)
                node = conditions.get(condition)
                if node.get('enable') == 'true':
                    try:
                        policy = dpath.util.get(cvaas_policy,
                                                condition, separator='.')
                    except Exception as ex:
                        raise Exception('Failed to fetch policy: %s', ex)

                    if policy:
                        condition = policy.get('conditions')
                        for c in condition:
                            log.info('Loading %s filter.', c)
                            for r in condition.get(c):
                                if r != 'Null':
                                    reports.setdefault(r, []).append(c)

        return reports

    def process_audit_report(self, policies):
        """Process the audit report for the VNF configuration."""
        log.info('Process the audit report for cvaas auditing.')

        policy = self.plugin.load_report()

        for _filter in policies.keys():
            log.info('Applying %s filter', _filter)

            pFilter = policy.get(_filter, None)
            if not pFilter:
                pFilter = self.report_filters[_filter]

            try:
                report = importutils.import_object(
                    pFilter,
                    results=self.cvaas_results,
                    policy=policies.get(_filter),
                    cvaas_report=self.cvaas_report,
                    ResultsFilter=self.ResultsFilter)
                report.run_report()
            except Exception as ex:
                log.error('Unable to load %s: %s', _filter, ex)
                pass
