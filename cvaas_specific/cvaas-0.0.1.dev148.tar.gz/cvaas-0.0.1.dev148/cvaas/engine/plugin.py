"""Plugins for cvaas."""


class CvaasPlugin(object):
    """Executes the steps relating to cvaas.

    Base plugin for cvaas VNF devices. This includes
    the supported/required implementation for API calls.
    Also provides *generic* implmentation of core features
    like loading configuration, running audit tests, etc,
    this way plugins that inherit from this base class and
    don't offer their own implematnation cal fall back on a
    general solution here.
    """

    def __init__(self):
        self.version = 'n/a'
        self.ResultsFilter = ''

    def load_configuration(self, config):
        """Load the configuration of the VNF device and format it
        so that it can compared to the gold standard template.
        """
        return {}

    def load_rules(self):
        """Load the rules of the VNF plugin so that the engine
           can compare the configuration, give results, and
           format the results so that policies can be applied to.
        """
        return {}

    def load_policy(self):
        """Load the policy of the VNF and apply the policy against
           the results fo the configuration audit.
        """
        return {}

    def load_report(self):
        """Create a report of the configuration audit."""
        return {}
