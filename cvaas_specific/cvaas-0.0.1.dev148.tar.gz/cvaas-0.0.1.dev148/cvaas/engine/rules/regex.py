"""Match configuration against a gold master regex."""
import logging
import re

from pyvaru.rules import PatternRule

log = logging.getLogger(__name__)


def apply_rule(configVal, goldStdVal, regex):
    log.info('Matching %s against %s', configVal, goldStdVal)

    cleanr = re.compile('<.*?>')
    r = re.sub(cleanr, '', goldStdVal)

    try:
        regex = regex.get(r)
    except KeyError:
        raise Exception('Failed to get regex key: %s', regex)

    try:
        result = PatternRule(configVal, 'label', pattern=regex).apply()
    except Exception as ex:
        log.exception('Failed to apply_rule %s (%s): %s',
                      configVal, goldStdVal, ex)

        return {'Result': 'FAIL',
                'Config Value': configVal,
                'Gold Standard Value': goldStdVal,
                'Score': -1}

    if result:
        return {'Result': 'OK',
                'Config Value': configVal,
                'Gold Standard Value': goldStdVal,
                'Score': 1}
    else:
        return {'Result': 'FAIL',
                'Config Value': configVal,
                'Gold Standard Value': goldStdVal,
                'Score': -1}
