import logging

import jsonschema


log = logging.getLogger(__name__)

PARAMS = ['MatchLevel', 'policy', 'GoldStdVal', 'type', 'permission', 'Attrib']


def rules_schema():
    """Return the schema of the golden master rule."""
    return {
        "items": {
            "MatchLevel": {"type": "string"},
            "Policy": {"type": "object"},
            "GoldStdVal": {"type": ["string", "array"]},
            "Permission": {"type": "string"}
        }
    }


def validate_rule(rule):
    """Make sure that the rule being sent to the engine is valid."""
    log.info('Validating rule: %s', rule)

    try:
        jsonschema.validate(rule, rules_schema())
    except jsonschema.ValidationError as exc:
        raise Exception('Schema validation failed for rule: %s', exc)

    for r in rule.keys():
        if r not in PARAMS:
            raise Exception('Unsupported value for rule: %s, valid '
                            'values are %s', r, PARAMS)

    return rule
