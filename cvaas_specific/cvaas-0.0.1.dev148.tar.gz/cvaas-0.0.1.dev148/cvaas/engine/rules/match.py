"""Match configuration against a gold master configuration."""
import logging

from pyvaru.rules import ChoiceRule
from pyvaru.rules import PatternRule

log = logging.getLogger(__name__)


def match_rule(configVal, goldStdVal):
    log.info('Matching %s against %s', configVal, goldStdVal)

    result = PatternRule(configVal, 'label', pattern=goldStdVal).apply()
    if result:
        return {'Result': 'OK',
                'Config Value': configVal,
                'Gold Standard Value': goldStdVal,
                'Score': 1}
    else:
        return {'Result': 'FAIL',
                'Config Value': configVal,
                'Gold Standard Value': goldStdVal,
                'Score': -1}


def match_list(configVal, goldStdVal):
    log.info('Matching %s against %s', configVal, goldStdVal)

    result = ChoiceRule(configVal, 'label', choices=goldStdVal).apply()
    if result:
        return {'Result': 'OK',
                'Config Value': configVal,
                'Gold Standard Value': goldStdVal,
                'Score': 1}
    else:
        return {'Result': 'FAIL',
                'Config Value': configVal,
                'Gold Standard Value': goldStdVal,
                'Score': -1}
