import logging

import six

from cvaas.engine.rules import match
from cvaas.engine.rules import regex
from cvaas.engine.rules import validate

log = logging.getLogger(__name__)


class MatchCheck(object):
    def __init__(self):
        self.regex = None

    def match_rule(self, **kwargs):
        """Match the rule from the golden master template and return
        the result.
        """
        config_val = kwargs.get('val')
        master = kwargs.get('master')
        regex = kwargs.get('regex')

        self.regex = regex

        rule = validate.validate_rule(master)
        val = self.from_dict(master, 'GoldStdVal')
        if val:
            log.info("Processing config value %s using %s.", config_val, rule)
            result = self.check_value(config_val, val)

        return result

    def from_dict(self, rule, key):
        """Fetch the rule value from the golden master template."""
        try:
            return rule.get(key)
        except KeyError as ex:
            raise Exception('Invalid formatting for %s (%s): %s', key, rule,
                            ex)
        except Exception as ex:
            raise Exception('Something wicked happening: %s (%s): %s', key,
                            rule, ex)

    def check_value(self, val, goldStdVal):
        """Check the master configuration value against the configuration
        value.
        """

        if isinstance(goldStdVal, six.text_type):
            if 'regex' in goldStdVal:
                result = regex.apply_rule(val,
                                          goldStdVal, self.regex)
            else:
                result = match.match_rule(val, goldStdVal)
            return result
        elif isinstance(goldStdVal, list):
            for index, config in enumerate(goldStdVal):
                if 'regex' in goldStdVal:
                    return regex.apply_rule(val, config, self.regex)
                else:
                    return match.match_list(val, config)
            return result
        elif isinstance(goldStdVal, dict):
            result = {}
            if 'regex' in goldStdVal:
                for k, v in six.iteritems(goldStdVal):
                    return regex.apply_rule(val, v, self.regex)
            else:
                    return match.match_rule(val, v)
        else:
            raise Exception('%s is an invalid data type for Cvaas (%s)',
                            goldStdVal, type(goldStdVal))
