import logging

import dpath.util

log = logging.getLogger(__name__)


def NIT(result):
    """Filter out the NIT results."""
    def _filter(x):
        if str(x) == 'NIT':
            return True
        return False

    return dpath.util.search(result, '**', yielded=True, afilter=_filter)


def NIC(result):
    """Filter out the NIC results."""
    def _filter(x):
        if str(x) == 'NIC':
            return True
        return False

    return dpath.util.search(result, '**', yielded=True, afilter=_filter)


def MOD(result):
    """Filter out the MOD results."""
    def _filter(x):
        if str(x) == 'MOD':
            return True
        return False

    return dpath.util.search(result, '**', yielded=True, afilter=_filter)


def OK(result):
    """Filter out the OK results."""
    def _filter(x):
        if str(x) == 'OK':
            return True
        return False

    return dpath.util.search(result, '**', yielded=True, afilter=_filter)


def FAIL(result):
    """Filter out the FAIL results."""
    def _filter(x):
        if str(x) == 'FAIL':
            return True
        return False

    return dpath.util.search(result, '**', yielded=True, afilter=_filter)
