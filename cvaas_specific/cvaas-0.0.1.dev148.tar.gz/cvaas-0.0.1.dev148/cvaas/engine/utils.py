import logging

log = logging.getLogger(__name__)


def load_rules(rules):
    """Run the configuration audit report given a VNF configuration."""
    log.info('Loading rules....')

    return {e.name: e.plugin for e in rules}
