import logging
import signal
import sys
import threading
import time

import redis

from cvaas.core import config
from cvaas.core.utils import setup_logging
from cvaas.core.worker import CvaasRunner

log = logging.getLogger(__name__)


def handle_signal(signal, frame):
    print('SIGINT recieved. Exiting..')
    sys.exit(1)


def main():
    setup_logging()

    signal.signal(signal.SIGINT, handle_signal)

    log.info('Starting cvaas subscriber..')

    r = redis.Redis(config.REDISHOST, db=1)
    client = CvaasRunner(r, ['cvaas'])
    t = threading.Thread(target=client.subscriber())
    t.setDaemon(True)
    t.start()
    while True:
        try:
            log.info('Waiting for data.')
            time.sleep(15)
        except redis.ConnectionError as ex:
            log.error('Failed to connect to %s: %s', config.REDISHOST, ex)
        except KeyboardInterrupt:
            print('Control-C pressed terminating server.')
            t.stop()
