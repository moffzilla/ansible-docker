# Load the cvaas-auditd daemon

import logging

import redis
from rq import Connection
from rq import Queue
from rq import Worker

from cvaas.core import config
from cvaas.core.utils import setup_logging

log = logging.getLogger(__name__)


def main():
    # Set up the logging in the docker containers.
    setup_logging()

    # Connect to the worker queue and wait for a job.
    conn = redis.from_url('redis://%s' % config.REDISHOST)

    with Connection(conn):
        worker = Worker(map(Queue, ['cvaas-worker']))
        worker.work()
