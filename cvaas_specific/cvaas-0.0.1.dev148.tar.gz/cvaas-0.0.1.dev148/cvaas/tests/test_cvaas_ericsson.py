from cvaas.plugins.ericsson import plugin
from cvaas.tests import base


class TestCvaasJob(base.TestCase):
    def setUp(self):
        super(TestCvaasJob, self).setUp()

        self.plugin = plugin.Ericsson()

    def test_load_config(self):
        fake_config = 'gsh create_diameter_application -da s6a -ls false -dh mmec17' \
            '-rn epc.mnc180.mcc311.3gppnetwork.org'
        config = self.plugin.load_configuration(fake_config)

        self.assertEqual(['create_diameter_application'], config.keys())

    def test_load_rules(self):
        policy = self.plugin.load_rules()
        self.assertEqual(['nic', 'nit', 'ok'], sorted(policy.keys()))
