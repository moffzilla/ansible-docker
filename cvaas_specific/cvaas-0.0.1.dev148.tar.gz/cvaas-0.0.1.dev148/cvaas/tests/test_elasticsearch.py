import mock

from cvaas.core import search
from cvaas.tests import base


class TestElasticSearch(base.TestCase):
    def setUp(self):
        super(TestElasticSearch, self).setUp()

    @mock.patch('elasticsearch.Elasticsearch')
    def test_elasticsearch_search(self, mock_elasticsearch):
        self.skipTest('Temporarily skip until figured out')
        res = search.query('cvaas', {})

    @mock.patch('elasticsearch.Elasticsearch')
    def test_elasticsearch_index(self, mock_elasticsearch):
        self.skipTest('Temporarily skip until figured out')

        index = mock.Mock()
        doc_type = mock.Mock()
        uid = mock.Mock()

        (created, version) = search.insert(index=index, doc_type=doc_type,
                                           uid=uid)

    @mock.patch('elasticsearch.Elasticsearch')
    def test_setup_elasticsearch(self, mock_elastic):
        self.skipTest('Temporarily skip until figured out')

        search.setup_elasticsearch()
