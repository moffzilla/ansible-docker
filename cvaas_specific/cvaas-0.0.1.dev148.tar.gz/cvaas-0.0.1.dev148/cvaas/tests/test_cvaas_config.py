import os

from cvaas.core import config
from cvaas.tests import base


class TestCvaasConfig(base.TestCase):
    def setUp(self):
        super(TestCvaasConfig, self).setUp()

    def test_redis_host(self):
        self.assertEqual(config.REDISHOST, 'redis')

    def test_set_redis_host(self):
        os.environ['REDISHOST'] = 'redis'
        self.assertEqual(config.REDISHOST, 'redis')

    def test_elastic_host(self):
        self.assertEqual(config.ELASTICHOST, 'elasticsearch')

    def test_set_elastic_host(self):
        os.environ['ELASTICHOST'] = 'elasticsearch'
        self.assertEqual(config.ELASTICHOST, 'elasticsearch')
