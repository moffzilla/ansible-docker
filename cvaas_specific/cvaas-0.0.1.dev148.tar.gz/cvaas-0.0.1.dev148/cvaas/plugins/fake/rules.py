import logging

log = logging.getLogger(__name__)


def check_not_in_template(config, template, results, regex=None):
    """Check to see if the configuration is in the template or not.
    """
    log.info('Checking for missing template rules for ericsson vmme.')

    return {}


def check_not_in_config(config, template, results, regex=None):
    """Check to see if master configuration is found or not.
    """
    log.info('Running NIC rules for ericsson vmme.')

    return {}


def check_configuration_values(config, template, results, regex=None):
    """Check for OK/Fail falures when comparing values.
    """
    log.info('Comparing configuration values for ericsson vmme.')

    return {}
