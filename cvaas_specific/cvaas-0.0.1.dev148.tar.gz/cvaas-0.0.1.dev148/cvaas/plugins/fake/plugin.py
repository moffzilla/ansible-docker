import logging

from cvaas.engine.plugin import CvaasPlugin

log = logging.getLogger(__name__)


class FakePlugin(CvaasPlugin):
    def __init__(self):
        super(FakePlugin, self).__init__()
        self.version = '0.1'
        self.ResultsFitler = '/Result'

    def load_configuration(self, config):
        """Load the configuration and parse the configuration into a json
        format type dictionary so that the configuration can be applied to
        a gold standard template.
        """
        fake_config = {}
        return fake_config

    def load_rules(self):
        """Load the cvaas' engine rules for the ericsson vmme policy
        rules."""
        log.info('Loading ericsson vmme engine rules.')

        return {
            'nic': 'cvaas.plugins.fake.rules.check_not_in_config',
            'nit': 'cvaas.plugins.fake.rules.check_not_in_template',
            'ok': 'cvaas.plugins.fake.rules.check_configuration_values'
        }

    def load_policy(self, policy):
        """Load the policy to be applied from the gold master configuration."""
        policy = {}
        return policy

    def load_report(self):
        """Load custom reports that are required for ericsson vmme."""
        return {}
