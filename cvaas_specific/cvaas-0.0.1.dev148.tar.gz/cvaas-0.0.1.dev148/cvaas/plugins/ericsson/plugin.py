import logging
import shlex

import args
import dpath.util
import six

from cvaas.engine.plugin import CvaasPlugin

log = logging.getLogger(__name__)


class Ericsson(CvaasPlugin):
    def __init__(self):
        super(Ericsson, self).__init__()
        self.version = '0.1'
        self.ResultsFilter = '/Result/gsh/element'

        self.cvaas_config = {}

    def load_configuration(self, config):
        """Load the configuration and parse the configuration into a json
        format type dictionary so that the configuration can be applied to
        a gold standard template.
        """
        log.info('Loading configuration for ericsson vmme.')

        cmds = {}

        for d in config.split('\n'):
            d = d.partition('#')[0]
            c = shlex.split(d)
            if len(c) != 0:
                if c[0] == 'gsh':
                    cmds.setdefault(c[1], []).append([x for x in c[2:]])

        for k, v in six.iteritems(cmds):
            for index, data in enumerate(v):
                index += 1
                arg = args.ArgsList(args=data)
                for a in arg.grouped:
                    if a is not '_':
                        for x in arg.grouped[a].all:
                            dpath.util.new(self.cvaas_config,
                                           '/%s/%s/%s'
                                           % (k, index, a.replace('-', '')), x)

        return self.cvaas_config

    def load_rules(self):
        """Load the cvaas' engine rules for the ericsson vmme policy
        rules."""
        log.info('Loading ericsson vmme engine rules.')

        return {
            'nit': 'cvaas.plugins.ericsson.rules.check_not_in_template',
            'nic': 'cvaas.plugins.ericsson.rules.check_not_in_config',
            'ok': 'cvaas.plugins.ericsson.rules.check_configuration_values'
        }

    def load_policy(self, policy):
        """Load the policy to be applied from the gold master configuration."""
        return dpath.util.get(policy, '/Rules/gsh/policy')

    def load_report(self):
        """Load custom reports that are required for ericsson vmme."""
        return {'ONAP-Log': 'cvaas.plugins.ericsson.onap.ONAPLog'}
