import logging

import dpath.util
import objectpath
import six

from cvaas.core import search
from cvaas.engine.reports import report

log = logging.getLogger(__name__)


class ONAPLog(report.CvaasReport):
    """Generates a report to be inserted into elasticsearch.
    """

    def __init__(self, results, policy, cvaas_report, ResultsFilter):
        super(ONAPLog, self).__init__(results, policy, cvaas_report,
                                      ResultsFilter)
        self.results = results
        self.policy = policy
        self.report = cvaas_report
        self.ResultsFilter = ResultsFilter

    def run_report(self):
        """Generate a report for the end user"""
        log.info('Running ONAP log.')

        dpath.util.new(self.cvaas_report, '/ID', self.report['id'])
        dpath.util.new(self.cvaas_report, '/Date', self.report['Date'])

        results = [x for x in six.itervalues(
            objectpath.Tree(self.results).execute('$.Audit.*'))]
        for result in results:
            for key, cmds in six.iteritems(result):
                for index, r in six.iteritems(cmds):
                    for k, v in six.iteritems(r):
                        for policy in self.policy:
                            if policy in ['NIT', 'NIC']:
                                if policy in v.keys():
                                    dpath.util.new(self.cvaas_report,
                                                   '/Results/gsh/%s/%s/%s'
                                                   % (key, index, k), policy)
                            elif policy in ['OK', 'FAIL']:
                                if 'Result' in v.keys():
                                    if v['Result'] == policy:
                                        dpath.util.new(self.cvaas_report,
                                                       '/Results/gsh/%s/%s/%s'
                                                       % (key, index, k), v)

        search.bulk_insert('cvaas-report', 'cvaas-doc',
                           self.cvaas_report.get('id'), self.cvaas_report)
