import logging

import dpath.util
import objectpath
import six

from cvaas.engine.rules import MatchCheck

NIT = 'Found in config. But not in gold master.'
NIC = 'Found in gold master. But not in config.'

log = logging.getLogger(__name__)


def check_not_in_template(config, template, results, regex=None):
    """Check to see if the configuration is in the template or not.
    """
    log.info('Checking for missing template rules for ericsson vmme.')

    keys = [str(x)
            for x in six.iterkeys(objectpath.Tree(template).execute(
                "$.Rules.gsh.element"))]
    for k, v in six.iteritems(config):
        if k in keys:
            elements = [str(x)
                        for x in six.iterkeys(objectpath.Tree(
                            template).execute(
                            "$.Rules.gsh.element.%s.element" % k))]
            for key, val in six.iteritems(v):
                args = [str(x) for x in six.iterkeys(val)]
                for arg in args:
                    if arg not in elements:
                        dpath.util.new(results,
                                       '/Audit/Rules.gsh.element/%s'
                                       '/%s/%s/NIT' % (
                                           k, key, arg),
                                       NIT)
    return results


def check_not_in_config(config, template, results, regex=None):
    """Check to see if master configuration is found or not.
    """
    log.info('Running NIC rules for ericsson vmme.')

    keys = [str(x) for x in six.iterkeys(config)]

    for k, v in six.iteritems(objectpath.Tree(template).execute(
            "$.Rules.gsh.element")):
        if k in keys:
            elements = [str(x)
                        for x in six.iterkeys(objectpath.Tree(template).execute
                                              ("$.Rules.gsh.element.%s.element"
                                               % k))]

            for index, cmd in six.iteritems(config[k]):
                args = [str(x) for x in six.iterkeys(cmd)]
                for element in elements:
                    if element not in args:
                        dpath.util.new(results,
                                       '/Audit/Rules.gsh.element/%s/'
                                       '%s/%s/NIC'
                                       % (k, index, element),
                                       NIC)
    return results


def check_configuration_values(config, template, results, regex):
    """Check for OK/Fail falures when comparing values.
    """
    log.info('Comparing configuration values for ericsson vmme.')

    ctree = objectpath.Tree(config)

    m = MatchCheck()
    pKeys = objectpath.Tree(template).execute("$.Rules.gsh.element")

    for k, v in six.iteritems(pKeys):
        if k in [str(x) for x in six.iterkeys(config)]:
            elements = [str(x)
                        for x in six.iterkeys(pKeys[k]['element'])]
            for index, cmds in six.iteritems(config[k]):
                for arg, val in six.iteritems(cmds):
                    if arg in elements:
                        e = pKeys[k]['element'][arg]
                        kwargs = {
                            'val': val,
                            'master': e,
                            'regex': regex
                        }
                        r = m.match_rule(**kwargs)

                        dpath.util.new(results,
                                       '/Audit/Rules.gsh.element/%s/'
                                       '%s/%s'
                                       % (k, index, arg), r)

    return results
