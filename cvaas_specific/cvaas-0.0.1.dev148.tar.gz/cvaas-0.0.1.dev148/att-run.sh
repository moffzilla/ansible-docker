#!/bin/bash

. ./att-stop.sh

touch logfile
> logfile

docker network create --driver bridge audit_network
#docker network inspect audit_network

#--publish 6379:6379 \
docker run -idt \
--name redis \
--net audit_network \
redis:3.2

ES=au4txvccrdp01-eth2.auk4.aic.cip.att.com

docker run -itd \
--name auditd \
--net audit_network \
--env LOG_FILE=/logfile \
--env REDISHOST=redis \
--env ELASTICHOST=${ES} \
--volume $PWD/logfile:/logfile:rw \
cvaas cvaas-queued
 
docker run -itd \
--name worker \
--net audit_network \
--env REDISHOST=redis \
--env ELASTICHOST=${ES} \
--env LOG_FILE=/logfile \
--volume $PWD/logfile:/logfile:rw \
cvaas cvaas-worker


. ./att-test-container.sh 
