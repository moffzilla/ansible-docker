from flask import Flask
from flask import jsonify
from flask import render_template
from flask import request
from flask import Response

import six

from cvaas.core import search

app = Flask(__name__, template_folder='templates')


@app.route('/')
def dashboard():
    data = search.query('cvaas-report', {'query': {'match_all': {}}})
    return render_template('dashboard.html', data=data)

    if __name__ == '__main__':
        app.run(debug=True, host='0.0.0.0')


@app.route('/raw')
def raw():
    uid = request.args.get('id')
    data = search.get('cvaas-report', uid)
    return jsonify(data['_source'])


@app.route('/config')
def config():
    uid = request.args.get('id')
    data = search.get('cvaas-report', uid)
    data = data['_source']
    return Response(data['payload']['CONTENT'],
                    mimetype='text/html')


@app.route('/results')
def results():
    uid = request.args.get('id')
    data = search.get('cvaas-report', uid)
    data = data['_source']
    return jsonify(data['Results']['gsh'])


@app.route('/report')
def report():
    uid = request.args.get('id')
    data = search.get('cvaas-report', uid)
    data = data['_source']

    uid = data['id']
    date = data['Date']
    d = data['Results']['gsh']

    result = {}
    RESULTS = []

    for key, value in six.iteritems(d):
        for index, data in six.iteritems(value):
            keys = [str(x) for x in six.iterkeys(data)]
            for k in keys:
                result = {}
                r = (d[key][index][k])
                if 'Result' in r:
                    result.update({'path':
                                   'Rules.gsh.element.%s.%s.%s'
                                   % (key, k, index)})
                    result.update({'result': r['Result']})
                    result.update({'config': r['Config Value']})
                    result.update({'GoldStdVal': r['Gold Standard Value']})
                    RESULTS.append(result)
    return render_template('report.html', uid=uid, date=date, data=RESULTS)
