To run the demo web service, make sure you have Flask installed:

sudo pip install flask

and then run the following:

 ./run.sh <ip address of server>
