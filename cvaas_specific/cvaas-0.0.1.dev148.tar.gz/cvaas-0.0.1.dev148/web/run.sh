#!/bin/bash

export FLASK_APP=$PWD/app.py
flask run -h $1 -p 5000
